#!/usr/bin/env bash

# TODO
# - check errors during synthesis and simulation
# - exit test
# - sourcing tcl argv

dir="../.."

printf "\n\n%s\n\n" "Starting design flow ..."

setsynopsys="source /software/scripts/init_synopsys_64.11"
setmentor="source /software/scripts/init_msim6.2g"

echo "Synthesis"; echo

# synthesize design
$setsynopsys >/dev/null
dc_shell -f syn.do > syn-transcript

cd $dir/sim/v1
echo "Forward: simulate netlist"; echo
# forward
# simulate netlist and get VCD
$setmentor >/dev/null
./netlist

cd - >/dev/null

# translate VCD in SAIF
vcd2saif -64 -input ${dir}/vcd/biquad_syn.vcd -output ${dir}/saif/biquad_syn.saif > vcd2saif-transcript

echo "Backward: report power estimation with annotated activity"; echo
# backward
# synthesize design 
# perform power analysis with annotates switching activity

$setsynopsys
dc_shell -f synsaif.do > backward-transcript

echo "DONE !"; echo

exit 0
